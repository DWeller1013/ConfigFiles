See [docs/src/6-contributing.md](./docs/src/6-contributing.md)
